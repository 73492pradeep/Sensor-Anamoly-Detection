/*
 * conversion.c
 *
 *  Created on: Feb 15, 2024
 *      Author: akhilesh
 */


#include "stm32f4xx_hal.h"
#include "stdint.h"
#include "math.h"

void float_to_array_1(float floatValue, uint8_t *byteArray) {
    uint8_t *floatBytes = (uint8_t *)&floatValue;

    for (int i = 0; i < 4 ; i++) {
        byteArray[i] = floatBytes[i];
      }
}
void float_to_array_2(float floatValue, uint8_t *byteArray) {
    uint8_t *floatBytes = (uint8_t *)&floatValue;
   int j = 4;
    for (int i = 0; i < 8 ; i++) {
        byteArray[j] = floatBytes[i];
        j++;
      }
}

void alti_int_to_uint8_t(int num,uint8_t *byteArray) {
    uint8_t *intBytes = (uint8_t *)&num;
   uint8_t j = 4;
    for (int i = 0; i < 8 ; i++) {
        byteArray[j] = intBytes[i];
        j++;
      }
}
