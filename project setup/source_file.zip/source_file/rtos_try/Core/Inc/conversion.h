/*
 * conversion.h
 *
 *  Created on: Feb 15, 2024
 *      Author: akhilesh
 */

#ifndef INC_CONVERSION_H_
#define INC_CONVERSION_H_

#include "stm32f4xx_hal.h"
void float_to_array_1(float , uint8_t *);
void float_to_array_2(float , uint8_t *);
void alti_int_to_uint8_t(int num,uint8_t *array);

#endif /* INC_CONVERSION_H_ */
